# Roblox Asset Favoriter

This tool allows you to automatically favorite a Roblox asset by its ID using one or more Roblox cookies.

## How it works

The tool will prompt you for a list of Roblox cookies, the number of favorites you want to add, and the asset ID you want to favorite. It will then use the provided cookies to favorite the asset.

## Clone repo

```sh
git clone https://github.com/YourUsername/RobloxAssetFavoriter
cd RobloxAssetFavoriter
```

### Install pnpm (if you haven't already)

```sh
npm i -g pnpm
```

### Install dependencies

```sh
pnpm i
pnpm i -g tsx
```

### Build

```sh
pnpm build
```

### Run

```sh
pnpm start
```

### Development

```sh
pnpm dev
```

This enables live refresh for development purposes.

## Notes

- You can provide multiple cookies by separating them with a comma.
- The number of favorites cannot exceed the number of cookies provided.
- This is just something I made in a small amount of time, expect bugs, glitches and crashes.
- If you want to contribute, make a pull request.
