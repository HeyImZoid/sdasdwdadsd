import axios from "axios";
import * as readline from "readline";
import noblox from "noblox.js";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const stats = { favorited: 0, errors: 0 };

async function favoriteAsset(assetId: number, cookie: string): Promise<boolean> {
  let robloxUserId: number | null = null;
  try {
    const currentUser = await noblox.setCookie(cookie);
    robloxUserId = currentUser.id;
    console.log(
      `[INFO] Logged in as: ${currentUser.name} (${currentUser.id})`
    );

    const csrfToken = await noblox.getGeneralToken();
    await axios.post(
      `https://catalog.roblox.com/v1/favorites/users/${robloxUserId}/assets/${assetId}/favorite`,
      {},
      {
        headers: {
          "x-csrf-token": csrfToken,
          Cookie: `.ROBLOSECURITY=${cookie}`,
        },
      }
    );
    stats.favorited++;
    console.log(`[SUCCESS] Favorited asset ${assetId} with user ${currentUser.name}`);
    return true;
  } catch (e: any) {
    stats.errors++;
    console.error(
      `[ERROR] Failed to favorite asset ${assetId} with a cookie. Reason: ${e.message}`
    );
    if (e.response) {
      console.error(`Status: ${e.response.status}`);
      console.error(`Data: ${JSON.stringify(e.response.data)}`);
    }
    return false;
  }
}

async function main() {
  rl.question(
    "Enter your Roblox cookies (separated by commas): ",
    async (cookiesStr) => {
      const cookies = cookiesStr.split(",").map((c) => c.trim());
      if (cookies.length === 0 || !cookies[0]) {
        console.log("No cookies provided. Exiting.");
        rl.close();
        return;
      }

      rl.question("How many favorites do you want?: ", (favoritesCountStr) => {
        const favoritesCount = parseInt(favoritesCountStr, 10);
        if (isNaN(favoritesCount) || favoritesCount <= 0) {
          console.log("Invalid number of favorites. Exiting.");
          rl.close();
          return;
        }

        if (favoritesCount > cookies.length) {
          console.error(
            "Error: Not enough cookies to perform the requested number of favorites."
          );
          rl.close();
          return;
        }

        rl.question(
          "Enter the Asset ID to favorite: ",
          async (assetIdStr) => {
            const assetId = parseInt(assetIdStr, 10);
            if (isNaN(assetId) || assetId <= 0) {
              console.log("Invalid Asset ID. Exiting.");
              rl.close();
              return;
            }

            console.log(`\nStarting to favorite asset ${assetId}...`);
            const cookiesToUse = cookies.slice(0, favoritesCount);

            for (const cookie of cookiesToUse) {
              await favoriteAsset(assetId, cookie);
              // Add a small delay to avoid rate-limiting
              await new Promise((resolve) => setTimeout(resolve, 500));
            }

            console.log("\nFinished!");
            console.log(`Total favorited: ${stats.favorited}`);
            console.log(`Errors: ${stats.errors}`);
            rl.close();
          }
        );
      });
    }
  );
}

main();
