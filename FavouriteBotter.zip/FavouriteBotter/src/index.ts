import fs from "fs";
import axios from "axios";
import noblox from "noblox.js";
import readline from "readline";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function ask(question: string): Promise<string> {
  return new Promise((resolve) => rl.question(question, resolve));
}

function loadCookies(path = "cookies.txt"): string[] {
  if (!fs.existsSync(path)) {
    console.error("[ERROR] cookies.txt not found.");
    return [];
  }
  const lines = fs
    .readFileSync(path, "utf8")
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 10);
  return Array.from(new Set(lines));
}

async function validateCookies(cookies: string[]): Promise<{ cookie: string; name: string; id: number }[]> {
  const valid: { cookie: string; name: string; id: number }[] = [];

  console.log("[INFO] Testing cookies...");

  for (const cookie of cookies) {
    try {
      await noblox.setCookie(`.ROBLOSECURITY=${cookie}`);
      const user = await noblox.getCurrentUser();
      console.log(`[✓] Cookie valid for ${user.UserName}`);
      valid.push({ cookie, name: user.UserName, id: user.UserID });
    } catch {
      console.log("[!] Invalid or expired cookie. Skipping.");
    }
    await new Promise((r) => setTimeout(r, 300));
  }

  return valid;
}

async function favouriteAsset(userId: number, cookie: string, assetId: number): Promise<"ok" | "already" | "failed"> {
  try {
    const token = await noblox.getGeneralToken();
    await axios.post(
      `https://favorites.roblox.com/v1/users/${userId}/favorites/assets/${assetId}`,
      null,
      {
        headers: {
          Cookie: `.ROBLOSECURITY=${cookie}`,
          "X-CSRF-TOKEN": token,
        },
        validateStatus: () => true,
      }
    );
    return "ok";
  } catch (err: any) {
    const status = err?.response?.status;
    if (status === 409 || status === 400) return "already";
    return "failed";
  }
}

async function main() {
  try {
    const assetInput = await ask("🎯 What is the asset ID you want to favourite? ");
    const assetId = Number(assetInput.trim());
    if (!Number.isInteger(assetId) || assetId <= 0) {
      console.error("[ERROR] Invalid asset ID.");
      rl.close();
      return;
    }

    const countInput = await ask("📦 How many unique favourites do you want? ");
    const targetCount = Number(countInput.trim());
    if (!Number.isInteger(targetCount) || targetCount <= 0) {
      console.error("[ERROR] Invalid number of favourites.");
      rl.close();
      return;
    }

    const rawCookies = loadCookies("cookies.txt");
    const validCookies = await validateCookies(rawCookies);

    if (validCookies.length < targetCount) {
      console.error(`[ERROR] Only ${validCookies.length} valid cookies found. Need ${targetCount}.`);
      rl.close();
      return;
    }

    const selected = validCookies.slice(0, targetCount);

    console.log(`[INFO] Starting favouriting for asset ${assetId} using ${targetCount} accounts...`);

    let success = 0;
    let already = 0;
    let failed = 0;

    for (const { cookie, name, id } of selected) {
      const result = await favouriteAsset(id, cookie, assetId);
      if (result === "ok") {
        console.log(`[✓] ${name} favourited asset ${assetId}`);
        success++;
      } else if (result === "already") {
        console.log(`[=] ${name} had already favourited ${assetId}`);
        already++;
      } else {
        console.log(`[!] ${name} could not favourite ${assetId}`);
        failed++;
      }
      await new Promise((r) => setTimeout(r, 400));
    }

    console.log(`\n[SUMMARY] Requested: ${targetCount} | Success: ${success} | Already: ${already} | Failed: ${failed}`);
  } finally {
    rl.close();
  }
}

main();
