import fs from "fs";
import axios from "axios";
import noblox from "noblox.js";
import readline from "readline";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

async function authenticate(cookie: string): Promise<{ id: number; name: string } | null> {
  try {
    await noblox.setCookie(`.ROBLOSECURITY=${cookie}`);
    const user = await noblox.getAuthenticatedUser();
    return { id: user.id, name: user.name };
  } catch {
    return null;
  }
}

async function favouriteAsset(userId: number, cookie: string, assetId: number): Promise<void> {
  try {
    const token = await noblox.getGeneralToken();
    await axios.post(
      `https://favorites.roblox.com/v1/users/${userId}/favorites/assets/${assetId}`,
      null,
      {
        headers: {
          Cookie: `.ROBLOSECURITY=${cookie}`,
          "X-CSRF-TOKEN": token,
        },
      }
    );
    console.log(`[✓] Favourited ${assetId} with user ${userId}`);
  } catch (err: any) {
    const code = err?.response?.status;
    if (code === 409 || code === 400) {
      console.log(`[!] Already favourited or invalid: ${assetId} (user ${userId})`);
    } else {
      console.error(`[ERROR] Failed for ${userId}: ${code || "unknown error"}`);
    }
  }
}

function loadCookies(): string[] {
  const filePath = "cookies.txt";
  if (!fs.existsSync(filePath)) {
    console.error("[ERROR] cookies.txt not found.");
    return [];
  }
  return fs.readFileSync(filePath, "utf-8")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter((line) => line.length > 10); // ignore blank or tiny lines
}

rl.question("Enter asset ID to favourite: ", async (input) => {
  const assetId = Number(input.trim());
  if (!assetId) {
    console.error("[ERROR] Invalid asset ID.");
    rl.close();
    return;
  }

  const cookies = loadCookies();
  if (cookies.length === 0) {
    console.error("[ERROR] No valid cookies loaded.");
    rl.close();
    return;
  }

  for (const cookie of cookies) {
    const user = await authenticate(cookie);
    if (!user) {
      console.error("[ERROR] Login failed.");
      continue;
    }
    console.log(`[INFO] Logged in as ${user.name}`);
    await favouriteAsset(user.id, cookie, assetId);
  }

  rl.close();
});
